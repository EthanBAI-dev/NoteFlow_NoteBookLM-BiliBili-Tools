import"./_virtual_wxt-html-plugins-DPbbfBKe.js";document.getElementById("pinGuideClose").addEventListener("click",function(){document.getElementById("pinGuide").style.display="none"});
