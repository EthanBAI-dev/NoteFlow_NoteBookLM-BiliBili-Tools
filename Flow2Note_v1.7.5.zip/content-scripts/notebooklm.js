var notebooklm=(function(){"use strict";var Ge=Object.defineProperty;var Ve=(_,T,B)=>T in _?Ge(_,T,{enumerable:!0,configurable:!0,writable:!0,value:B}):_[T]=B;var M=(_,T,B)=>Ve(_,typeof T!="symbol"?T+"":T,B);function _(t){return t}const T="jetpackSettings",B={autoRenamePastedSources:!0,ai:{enabled:!1,provider:"deepseek",apiKey:"",model:"",promptStyle:"smooth",customPrompt:""}};async function fe(){try{const e=(await chrome.storage.local.get(T))[T];return ne(B,e||{})}catch{return{...B}}}function ne(t,e){const n={...t};for(const r of Object.keys(e)){const o=e[r],s=t[r];o&&typeof o=="object"&&!Array.isArray(o)&&s&&typeof s=="object"&&!Array.isArray(s)?n[r]=ne(s,o):o!==void 0&&(n[r]=o)}return n}const pe={matches:["https://notebooklm.google.com/*"],runAt:"document_idle",main(){if(window.__NLM_IMPORTER_LOADED__)return;window.__NLM_IMPORTER_LOADED__=!0,console.log("NotebookLM Jetpack content script loaded"),chrome.runtime.onMessage.addListener((a,u,i)=>{if(a.type==="PING"){const l=!!ie();return i({ready:l}),!0}if(a.type==="IMPORT_URL")return he(a.url).then(l=>i({success:l})).catch(l=>{console.error("Import error:",l),i({success:!1,error:l.message})}),!0;if(a.type==="IMPORT_TEXT")return we(a.text,a.title,a.renamePrefix).then(l=>i({success:l})).catch(l=>{console.error("Import text error:",l),i({success:!1,error:l.message})}),!0;if(a.type==="GET_FAILED_SOURCES"){const l=ce();return i({success:!0,data:l}),!0}if(a.type==="GET_WECHAT_SOURCES"){const l=le();return i({success:!0,data:l}),!0}if(a.type==="RESCUE_SOURCE_DONE")return Z(a.results),i({success:!0}),!0;if(a.type==="GET_NOTEBOOK_INFO"){const l=_e();return i({success:!0,data:l}),!0}}),setTimeout(()=>{V(),Y()},2e3),setTimeout(()=>oe(),2500),new MutationObserver(()=>{!document.getElementById("nlm-more-actions-btn")&&document.querySelector(".scroll-area-desktop")&&oe()}).observe(document.body,{childList:!0,subtree:!0});let e=document.querySelectorAll(".single-source-container").length,n=document.querySelectorAll(".single-source-error-container").length,r=null,o=null;function s(){const a=document.getElementById("nlm-rescue-banner"),u=document.getElementById("nlm-rescue-btn");(u==null?void 0:u.disabled)===!0||(a==null||a.remove(),V());const l=document.getElementById("nlm-repair-banner"),f=document.getElementById("nlm-repair-btn");(f==null?void 0:f.disabled)===!0||(l==null||l.remove(),Y())}const m=new MutationObserver(()=>{r||(r=setTimeout(()=>{r=null;const a=document.querySelectorAll(".single-source-container").length,u=document.querySelectorAll(".single-source-error-container").length;if(a!==e||u!==n){e=a,n=u,s(),o&&clearTimeout(o);const i=[5e3,1e4,18e3];let l=0;const f=()=>{l>=i.length||(o=setTimeout(()=>{n=document.querySelectorAll(".single-source-error-container").length,s(),l++,f()},l===0?i[0]:i[l]-i[l-1]))};f()}else document.getElementById("nlm-rescue-banner")||V(),document.getElementById("nlm-repair-banner")||Y()},800))}),c=document.querySelector(".scroll-area-desktop");c&&m.observe(c,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class"]})}};function re(){const t=document.querySelectorAll(".single-source-container"),e=[];return t.forEach(n=>{n.querySelector("mat-checkbox.mat-mdc-checkbox-checked, .mat-mdc-checkbox-checked")&&e.push(n)}),e}function oe(){if(document.getElementById("nlm-more-actions-btn"))return;const t=document.querySelector(".scroll-area-desktop");if(!t||document.querySelectorAll(".single-source-container").length===0)return;if(!document.getElementById("nlm-more-actions-style")){const n=document.createElement("style");n.id="nlm-more-actions-style",n.textContent=`
      #nlm-more-actions-btn {
        display: block;
        margin: 4px 16px 8px;
        padding: 0;
        border: none;
        background: transparent;
        color: #9aa0a6;
        font-family: 'Google Sans', Roboto, sans-serif;
        font-size: 11px;
        cursor: pointer;
        transition: color 0.15s;
        position: relative;
        text-align: left;
      }
      #nlm-more-actions-btn:hover {
        color: #5f6368;
      }
      #nlm-more-actions-menu {
        position: absolute;
        bottom: 100%;
        left: 0;
        margin-bottom: 4px;
        background: white;
        border: 1px solid #dadce0;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        z-index: 1000;
        min-width: 180px;
        padding: 4px 0;
        font-family: 'Google Sans', Roboto, sans-serif;
      }
      #nlm-more-actions-menu .nlm-menu-item {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 16px;
        font-size: 13px;
        color: #3c4043;
        cursor: pointer;
        transition: background 0.1s;
        border: none;
        background: none;
        width: 100%;
        text-align: left;
      }
      #nlm-more-actions-menu .nlm-menu-item:hover {
        background: #f1f3f4;
      }
      #nlm-more-actions-menu .nlm-menu-item.nlm-menu-danger {
        color: #d93025;
      }
      #nlm-more-actions-menu .nlm-menu-item.nlm-menu-danger:hover {
        background: #fce8e6;
      }
      #nlm-more-actions-menu .nlm-menu-item:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      #nlm-more-actions-progress {
        margin: 4px 16px 8px;
        font-size: 11px;
        color: #5f6368;
        font-family: 'Google Sans', Roboto, sans-serif;
      }
    `,document.head.appendChild(n)}const e=document.createElement("button");e.id="nlm-more-actions-btn",e.textContent=x("moreActions.btn"),t.appendChild(e),e.addEventListener("click",n=>{n.stopPropagation(),be()}),document.addEventListener("click",n=>{const r=document.getElementById("nlm-more-actions-menu");r&&!n.target.closest("#nlm-more-actions-btn, #nlm-more-actions-menu")&&r.remove()})}function be(){const t=document.getElementById("nlm-more-actions-menu");if(t){t.remove();return}const e=document.getElementById("nlm-more-actions-btn");if(!e)return;const n=re(),r=document.createElement("div");r.id="nlm-more-actions-menu";const o=document.createElement("button");o.className="nlm-menu-item nlm-menu-danger",o.textContent=n.length>0?`🗑 ${x("select.delete")} (${n.length})`:`🗑 ${x("select.delete")}`,o.disabled=n.length===0,o.addEventListener("click",async()=>{r.remove(),await xe()}),r.appendChild(o),e.appendChild(r)}async function xe(){var s;const t=re();if(t.length===0||!confirm(x("select.confirm",{n:t.length})))return;const e=document.getElementById("nlm-more-actions-btn"),n=document.createElement("div");n.id="nlm-more-actions-progress",(s=e==null?void 0:e.parentElement)==null||s.insertBefore(n,e.nextSibling),e&&(e.style.display="none");let r=0;const o=t.length;for(const m of t){n.textContent=x("select.deleting",{n:r+1,t:o});try{await Ae(m),r++}catch(c){console.warn("[bulkDelete] Failed to delete source, skipping:",c)}await p(300)}n.textContent=x("select.done",{n:r}),await p(2e3),n.remove(),e&&(e.style.display="")}async function Ae(t){const e=t.querySelector(".source-item-more-button")||t.querySelector('button[aria-label="更多"], button[aria-label="More"]')||t.querySelector("button");if(!e)throw new Error("Menu button not found");e.scrollIntoView({block:"center",behavior:"instant"}),await p(200),e.click(),await p(500);const n=document.querySelector(".more-menu-delete-source-button")||Array.from(document.querySelectorAll('[role="menuitem"], .mat-mdc-menu-item')).find(o=>{var m;const s=((m=o.textContent)==null?void 0:m.trim())||"";return s.includes("移除来源")||s.includes("Remove source")||s.includes("Delete source")});if(!n)throw document.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",bubbles:!0})),new Error("Delete menu item not found");n.click(),await p(800);const r=document.querySelector("mat-dialog-container .submit-button")||Array.from(document.querySelectorAll("button")).find(o=>{var m;const s=((m=o.textContent)==null?void 0:m.trim())||"";return s==="Delete"||s==="删除"||s==="移除"});if(!r)throw document.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",bubbles:!0})),new Error("Delete confirm button not found");r.click(),await p(1e3)}async function he(t){try{await se();let e=$(".urls-input-container textarea")||await F(["粘贴任何链接","粘贴","Paste any link","Paste any links","Paste"],500);if(!e){const r=$(".drop-zone-icon-button",o=>{var s,m,c;return!!((c=(m=(s=o.querySelector("img"))==null?void 0:s.textContent)==null?void 0:m.trim())!=null&&c.includes("link"))})||await G(["link"],500)||await R(["网站","Website","Websites","Link"],3e3);if(!r)throw new Error("Website button not found in dialog");r.click(),await p(500),e=$(".urls-input-container textarea")||await F(["粘贴任何链接","粘贴","Paste any link","Paste any links","Paste"],3e3)}if(!e)throw new Error("URL input textarea not found");await O(e,t);const n=await R(["插入","Insert"],3e3);if(!n)throw new Error("Insert button not found");return n.click(),await p(1500),!0}catch(e){return console.error("Failed to import URL:",e),!1}}const ye=["粘贴的文字","复制的文字","Copied text","Copied Text","Pasted text","Pasted Text"];async function we(t,e,n){var m,c;const r=await fe(),o=!!e&&r.autoRenamePastedSources,s=new WeakSet;o&&document.querySelectorAll(".single-source-container").forEach(a=>{s.add(a)});try{await se();let a=$(".copied-text-input-textarea")||await F(["在此处粘贴文字","粘贴文字","粘贴","Paste text here","Paste"],500);if(!a){const i=$(".back-button")||await G(["arrow_back"],200);i&&(i.click(),await p(500));const l=$(".drop-zone-icon-button",f=>{var w,C,L;return!!((L=(C=(w=f.querySelector("img"))==null?void 0:w.textContent)==null?void 0:C.trim())!=null&&L.includes("content_paste"))})||await G(["content_paste"],500)||await R(["复制的文字","复制的文本","Copied text","Text"],3e3);if(!l)throw new Error("Copied text button not found in dialog");l.click(),await p(500),a=$(".copied-text-input-textarea")||await F(["在此处粘贴文字","粘贴文字","粘贴","Paste text here","Paste"],3e3)}if(!a){const i=Ee();if(i.length===0)throw new Error("Text area not found");a=i[i.length-1]}if(e){const i=await ke(["来源名称","标题","Source name","Title","title"],500);i&&await O(i,e)}await O(a,t),await p(800);const u=await R(["插入","Insert"],5e3);if(!u)throw new Error("Insert button not found");for(let i=0;i<10&&u.disabled;i++)await p(300);u.click();for(let i=0;i<10&&(await p(1e3),!!I());i++);if(o){await p(3e3);const l=[...document.querySelectorAll(".single-source-container")].find(f=>!s.has(f));if(l){const f=(c=(m=l.querySelector(".source-title"))==null?void 0:m.textContent)==null?void 0:c.trim();if(f&&ye.includes(f)){const w=`${n||""}${e}`;console.log(`[importText] Source still has default name "${f}", renaming to "${w}"`);try{await ve(f,w)}catch(C){console.warn("[importText] Rename failed (non-fatal):",C),K()}}}else console.log("[importText] Could not locate newly-added source (possibly deduped or still rendering)")}return!0}catch(a){return console.error("Failed to import text:",a),!1}}function I(){return document.querySelector("mat-dialog-container")||document.querySelector(".mat-mdc-dialog-container")}function Se(t){return!!(t.querySelector(".drop-zone-container")||t.querySelector(".urls-input-container")||t.querySelector(".copied-text-container"))}function $(t,e){const n=I();if(!n)return null;if(e){const r=n.querySelectorAll(t);for(const o of r)if(e(o))return o;return null}return n.querySelector(t)}async function se(){const t=I();if(t){if(Se(t))return;const r=t.querySelector(".close-button, .dialog-title-close-icon, .cancel-button");r?(r.click(),await p(500)):(document.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",bubbles:!0})),await p(500))}const e=ie();if(!e)throw new Error("Add source button not found");if(e.click(),await p(500),!await ue("mat-dialog-container, .mat-mdc-dialog-container",3e3))throw new Error("Add source dialog did not open")}function ie(){var s,m;const t=document.querySelector(".add-source-button");if(t)return t;const e=['button[aria-label*="Add source"]','button[aria-label*="添加来源"]'];for(const c of e){const a=document.querySelector(c);if(a)return a}const o=(document.querySelector('.source-panel, [class*="source"]')||document).querySelectorAll("button");for(const c of o){const a=c.querySelectorAll("img, .material-symbols-outlined, .material-icons, mat-icon");for(const u of a)if(((s=u.textContent)==null?void 0:s.trim())==="add"){const i=((m=c.textContent)==null?void 0:m.trim())||"";if(i.includes("source")||i.includes("来源")||i.includes("Add"))return c}}return null}async function R(t,e=3e3){var r,o;const n=Date.now();for(;Date.now()-n<e;){const s=[I(),document.querySelector('[role="dialog"]'),document].filter(Boolean);for(const m of s){const c=m.querySelectorAll("button");for(const u of c){const i=((r=u.textContent)==null?void 0:r.trim())||"";for(const l of t)if(i.includes(l))return u}const a=m.querySelectorAll('span.mdc-button__label, [class*="button__label"]');for(const u of a){const i=((o=u.textContent)==null?void 0:o.trim())||"";for(const l of t)if(i===l){const f=u.closest('button, [role="button"], a');return f||u.parentElement}}}await p(100)}return null}async function F(t,e=3e3){var r,o,s,m,c;const n=Date.now();for(;Date.now()-n<e;){const a=document.querySelectorAll('textarea, input[type="text"], input[type="url"], input:not([type])');for(const i of a){const l=((r=i.placeholder)==null?void 0:r.toLowerCase())||"";for(const f of t)if(l.includes(f.toLowerCase()))return i}const u=I()||document.querySelector('[role="dialog"]');if(u){const i=u.querySelectorAll('[role="textbox"], [contenteditable="true"]');for(const l of i){const f=((o=l.getAttribute("aria-placeholder"))==null?void 0:o.toLowerCase())||((s=l.getAttribute("placeholder"))==null?void 0:s.toLowerCase())||((c=(m=l.dataset)==null?void 0:m.placeholder)==null?void 0:c.toLowerCase())||"";for(const w of t)if(f.includes(w.toLowerCase()))return l}}await p(100)}return null}async function ke(t,e=3e3){var r;const n=Date.now();for(;Date.now()-n<e;){const o=document.querySelectorAll('input[type="text"], input:not([type])');for(const s of o){const m=((r=s.placeholder)==null?void 0:r.toLowerCase())||"";for(const c of t)if(m.includes(c.toLowerCase()))return s}await p(100)}return null}function Ee(){const t=document.querySelector('[role="dialog"]');return t?Array.from(t.querySelectorAll("textarea")):[]}async function O(t,e){var o;t.focus();const n=(o=Object.getOwnPropertyDescriptor(t instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,"value"))==null?void 0:o.set;n?n.call(t,e):t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0}));const r=new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:e});t.dispatchEvent(r),await p(200)}function p(t){return new Promise(e=>setTimeout(e,t))}function K(){const t=I();if(!t)return;const e=t.querySelector(".close-button, .cancel-button, .dialog-title-close-icon");e?e.click():document.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",bubbles:!0}))}async function G(t,e=3e3){var r;const n=Date.now();for(;Date.now()-n<e;){const o=I()||document.querySelector('[role="dialog"]');if(o){const s=o.querySelectorAll("button");for(const m of s){const c=m.querySelectorAll("img, .material-symbols-outlined, .material-icons, mat-icon");for(const a of c){const u=((r=a.textContent)==null?void 0:r.trim())||"";if(t.includes(u))return m}}}await p(100)}return null}async function ve(t,e){var a,u;const n=document.querySelectorAll(".single-source-container");let r=null;for(let i=n.length-1;i>=0;i--){const l=n[i],f=l.querySelector(".source-title-column");if(((a=f==null?void 0:f.textContent)==null?void 0:a.trim())===t&&(r=l.querySelector(".source-item-more-button"),r||(r=l.querySelector('button[aria-label="更多"], button[aria-label="More"]')),r))break}if(!r)throw new Error(`Source "${t}" not found in source list`);r.scrollIntoView({block:"center",behavior:"instant"}),await p(500);const o=6;let s=null;for(let i=0;i<o;i++){r.click();const l=600+i*400;if(await p(l),s=document.querySelector(".more-menu-edit-source-button")||await Ce(["edit","drive_file_rename_outline"],["重命名来源","Rename source","Rename"],3e3),s)break;console.log(`[rename] Attempt ${i+1}/${o}: menu not found, retrying...`),document.body.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",bubbles:!0,cancelable:!0})),await p(800+i*300)}if(!s)throw new Error(`Rename menu item not found after ${o} attempts`);s.click(),await p(800);const m=await ue(".edit-source-dialog input",3e3)||await Te(["来源名称","Source name"],3e3);if(!m)throw K(),new Error("Rename input not found");m.select(),await p(100),await O(m,e);const c=document.querySelector("mat-dialog-container .submit-button")||await R(["保存","Save"],3e3);if(!c)throw K(),new Error("Save button not found");c.click(),await p(500),(u=I())!=null&&u.querySelector(".edit-source-dialog")&&(console.warn("[rename] Dialog still open after Save — force closing"),K(),await p(300))}async function Ce(t,e,n=3e3){var o,s;const r=Date.now();for(;Date.now()-r<n;){const m=document.querySelectorAll('[role="menuitem"], .mat-menu-item, .mat-mdc-menu-item, button[mat-menu-item]');for(const c of m){const a=c.querySelectorAll("img, .material-symbols-outlined, .material-icons, mat-icon");for(const u of a){const i=((o=u.textContent)==null?void 0:o.trim())||"";if(t.includes(i))return c}}for(const c of m){const a=((s=c.textContent)==null?void 0:s.trim())||"";for(const u of e)if(a.includes(u))return c}await p(100)}return null}async function Te(t,e=3e3){var r,o;const n=Date.now();for(;Date.now()-n<e;){const s=document.querySelectorAll("mat-label, label, .mat-mdc-floating-label");for(const m of s){const a=(((o=(r=m.textContent)==null?void 0:r.trim())==null?void 0:o.replace(/\*$/,"").trim())||"").toLowerCase();for(const u of t)if(a===u.toLowerCase()||a.includes(u.toLowerCase())){const i=m.closest("mat-form-field, .mat-mdc-form-field, .mat-form-field");if(i){const f=i.querySelector("input");if(f)return f}const l=m.htmlFor;if(l){const f=document.getElementById(l);if(f)return f}}}await p(100)}return null}const qe=navigator.language.startsWith("zh"),Ie={"moreActions.btn":["··· 更多操作","··· More actions"],"select.delete":["删除选中","Delete selected"],"select.deleting":["删除中 {n}/{t}...","Deleting {n}/{t}..."],"select.confirm":["确定删除 {n} 个来源？此操作不可撤销。","Delete {n} sources? This cannot be undone."],"select.done":["已删除 {n} 个来源","{n} sources deleted"],"rescue.text":["{n} 个来源导入失败，可尝试抢救","{n} failed source imports — try rescue"],"rescue.btn":["↻ 抢救","↻ Rescue"],"rescue.pending":["待抢救","Pending"],"rescue.running":["抢救中...","Rescuing..."],"rescue.done":["抢救完成：<strong>{s}</strong> 成功","Rescue done: <strong>{s}</strong> succeeded"],"rescue.doneFail":["，<strong>{f}</strong> 失败",", <strong>{f}</strong> failed"],"rescue.removeFailed":["移除已抢救的失败来源","Remove rescued failed sources"],"repair.text":["{n} 个来源需要修复（内容可能为空）","{n} sources need repair (may be empty)"],"repair.btn":["🔧 修复","🔧 Repair"],"repair.pending":["待修复","Pending"],"repair.running":["修复中...","Repairing..."],"repair.done":["修复完成：<strong>{s}</strong> 成功","Repair done: <strong>{s}</strong> succeeded"],"repair.doneFail":["，<strong>{f}</strong> 失败",", <strong>{f}</strong> failed"],"repair.removeOld":["移除原始失败来源","Remove original failed sources"],success:["成功","Success"],failed:["失败","Failed"],done:["✓ 完成","✓ Done"],close:["关闭","Close"]};function x(t,e){const n=Ie[t];let r=n?n[qe?0:1]:t;if(e)for(const[o,s]of Object.entries(e))r=r.replace(new RegExp(`\\{${o}\\}`,"g"),String(s));return r}function V(){var r,o;if(document.getElementById("nlm-rescue-banner"))return;const t=ce();if(t.length===0)return;const e=document.querySelector(".scroll-area-desktop");if(!e)return;const n=document.createElement("div");n.id="nlm-rescue-banner",n.innerHTML=`
    <style>
      #nlm-rescue-banner {
        margin: 8px 12px;
        padding: 10px 12px;
        background: #fffbeb;
        border: 1px solid #fcd34d;
        border-radius: 10px;
        font-family: 'Google Sans', Roboto, sans-serif;
        font-size: 13px;
        color: #92400e;
        animation: nlm-fade-in 0.3s ease;
      }
      @keyframes nlm-fade-in {
        from { opacity: 0; transform: translateY(-4px); }
        to { opacity: 1; transform: translateY(0); }
      }
      #nlm-rescue-banner .nlm-rescue-header {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      #nlm-rescue-banner .nlm-rescue-icon {
        width: 16px; height: 16px; flex-shrink: 0;
      }
      #nlm-rescue-banner .nlm-rescue-text { flex: 1; }
      #nlm-rescue-banner .nlm-rescue-btn {
        padding: 4px 12px;
        background: #f59e0b;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
        transition: background 0.15s;
      }
      #nlm-rescue-banner .nlm-rescue-btn:hover { background: #d97706; }
      #nlm-rescue-banner .nlm-rescue-btn:disabled {
        opacity: 0.6; cursor: not-allowed;
      }
      #nlm-rescue-banner .nlm-rescue-details {
        margin-top: 8px;
        padding-top: 8px;
        border-top: 1px solid #fde68a;
        font-size: 12px;
        color: #78350f;
      }
      #nlm-rescue-banner .nlm-rescue-item {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 3px 0;
        overflow: hidden;
      }
      #nlm-rescue-banner .nlm-rescue-item-url {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        flex: 1;
      }
      #nlm-rescue-banner .nlm-rescue-status {
        flex-shrink: 0;
        font-size: 11px;
      }
      #nlm-rescue-banner .nlm-rescue-success { color: #16a34a; }
      #nlm-rescue-banner .nlm-rescue-error { color: #dc2626; }
      #nlm-rescue-banner .nlm-rescue-spinner {
        display: inline-block;
        width: 12px; height: 12px;
        border: 2px solid #fff;
        border-top-color: transparent;
        border-radius: 50%;
        animation: nlm-spin 0.6s linear infinite;
      }
      @keyframes nlm-spin { to { transform: rotate(360deg); } }
      #nlm-rescue-banner .nlm-dismiss {
        background: none; border: none; color: #b45309;
        cursor: pointer; font-size: 16px; padding: 0 2px;
        line-height: 1; flex-shrink: 0;
      }
      #nlm-rescue-banner .nlm-dismiss:hover { color: #92400e; }
      #nlm-rescue-banner .nlm-rescue-footer {
        margin-top: 10px;
        padding-top: 8px;
        border-top: 1px solid #fde68a;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      #nlm-rescue-banner .nlm-rescue-footer label {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: #78350f;
        cursor: pointer;
        flex: 1;
      }
      #nlm-rescue-banner .nlm-rescue-footer input[type="checkbox"] {
        accent-color: #f59e0b;
        width: 14px; height: 14px;
      }
      #nlm-rescue-banner .nlm-rescue-done-btn {
        padding: 6px 16px;
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.15s;
      }
      #nlm-rescue-banner .nlm-rescue-done-btn:hover { background: #15803d; }
    </style>
    <div class="nlm-rescue-header">
      <svg class="nlm-rescue-icon" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
        <line x1="12" y1="9" x2="12" y2="13"/>
        <line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
      <span class="nlm-rescue-text">
        ${x("rescue.text",{n:`<strong>${t.length}</strong>`})}
      </span>
      <button class="nlm-rescue-btn" id="nlm-rescue-btn">
        ${x("rescue.btn")}
      </button>
      <button class="nlm-dismiss" id="nlm-rescue-dismiss" title="${x("close")}">×</button>
    </div>
    <div class="nlm-rescue-details" id="nlm-rescue-details" style="display:none">
      ${t.map(s=>`
        <div class="nlm-rescue-item" data-url="${s}">
          <span class="nlm-rescue-item-url" title="${s}">${s}</span>
          <span class="nlm-rescue-status" data-status="pending">${x("rescue.pending")}</span>
        </div>
      `).join("")}
    </div>
  `,e.insertBefore(n,e.firstChild),(r=document.getElementById("nlm-rescue-btn"))==null||r.addEventListener("click",()=>{const s=document.getElementById("nlm-rescue-btn");s.disabled=!0,s.innerHTML=`<span class="nlm-rescue-spinner"></span> ${x("rescue.running")}`;const m=document.getElementById("nlm-rescue-details");m&&(m.style.display="block");const c=chrome.runtime.connect({name:"rescue-sources"});c.postMessage({urls:t}),c.onMessage.addListener(a=>{if(a.phase==="item-start"){const u=document.querySelector(`#nlm-rescue-details .nlm-rescue-item[data-url="${CSS.escape(a.url)}"]`),i=u==null?void 0:u.querySelector(".nlm-rescue-status");if(i){i.className="nlm-rescue-status",i.textContent="";const l=document.createElement("span");l.className="nlm-rescue-spinner",i.appendChild(l)}}else if(a.phase==="item-done"){const u=a.result,i=document.querySelector(`#nlm-rescue-details .nlm-rescue-item[data-url="${CSS.escape(u.url)}"]`),l=i==null?void 0:i.querySelector(".nlm-rescue-status");l&&(u.status==="success"?(l.className="nlm-rescue-status nlm-rescue-success",l.textContent=`✓ ${u.title||x("success")}`):(l.className="nlm-rescue-status nlm-rescue-error",l.textContent=`✗ ${u.error||x("failed")}`))}else a.phase==="done"?(Z(a.results||[]),c.disconnect()):a.phase==="error"&&(Z([]),c.disconnect())})}),(o=document.getElementById("nlm-rescue-dismiss"))==null||o.addEventListener("click",()=>{n.remove()})}function Z(t){var m;const e=document.getElementById("nlm-rescue-btn"),n=t.filter(c=>c.status==="success").length,r=t.filter(c=>c.status==="error").length;e&&(e.style.display="none");const o=document.querySelector("#nlm-rescue-banner .nlm-rescue-text");o&&(o.innerHTML=`${x("rescue.done",{s:n})}${r>0?x("rescue.doneFail",{f:r}):""}`);const s=document.getElementById("nlm-rescue-details");s&&(s.style.display="block");for(const c of t){const a=document.querySelector(`#nlm-rescue-details .nlm-rescue-item[data-url="${CSS.escape(c.url)}"]`);if(!a)continue;const u=a.querySelector(".nlm-rescue-status");u&&(c.status==="success"?(u.className="nlm-rescue-status nlm-rescue-success",u.textContent=`✓ ${c.title||x("success")}`):(u.className="nlm-rescue-status nlm-rescue-error",u.textContent=`✗ ${c.error||x("failed")}`))}if(n>0){const c=document.getElementById("nlm-rescue-banner");if(c&&!document.getElementById("nlm-rescue-footer")){const a=document.createElement("div");a.id="nlm-rescue-footer",a.className="nlm-rescue-footer",a.innerHTML=`
        <label>
          <input type="checkbox" id="nlm-rescue-remove-failed" checked />
          ${x("rescue.removeFailed")}
        </label>
        <button class="nlm-rescue-done-btn" id="nlm-rescue-done-btn">${x("done")}</button>
      `,c.appendChild(a),(m=document.getElementById("nlm-rescue-done-btn"))==null||m.addEventListener("click",async()=>{const u=document.getElementById("nlm-rescue-remove-failed");u!=null&&u.checked&&await Be(),c.remove()})}}}async function Be(){const t=document.querySelectorAll(".single-source-error-container");if(t.length===0)return;const e=t[0],n=e.querySelector(".source-item-more-button")||e.querySelector("button");if(!n)return;n.click(),await p(500);const r=document.querySelector('[class*="more-menu-remove-all-fail"]')||Array.from(document.querySelectorAll('[role="menuitem"], .mat-mdc-menu-item')).find(o=>{var m;const s=((m=o.textContent)==null?void 0:m.trim())||"";return s.includes("移除所有失败的来源")||s.includes("Remove all failed")});if(r){r.click(),await p(500);return}document.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",bubbles:!0}))}function Y(){var o,s;if(document.getElementById("nlm-repair-banner"))return;const t=le();if(t.length===0)return;const e=document.querySelector(".scroll-area-desktop");if(!e)return;const n=document.createElement("div");n.id="nlm-repair-banner",n.innerHTML=`
    <style>
      #nlm-repair-banner {
        margin: 8px 12px;
        padding: 10px 12px;
        background: #eff6ff;
        border: 1px solid #93c5fd;
        border-radius: 10px;
        font-family: 'Google Sans', Roboto, sans-serif;
        font-size: 13px;
        color: #1e40af;
        animation: nlm-fade-in 0.3s ease;
      }
      #nlm-repair-banner .nlm-repair-header {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      #nlm-repair-banner .nlm-repair-icon {
        width: 16px; height: 16px; flex-shrink: 0;
      }
      #nlm-repair-banner .nlm-repair-text { flex: 1; }
      #nlm-repair-banner .nlm-repair-btn {
        padding: 4px 12px;
        background: #3b82f6;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
        transition: background 0.15s;
      }
      #nlm-repair-banner .nlm-repair-btn:hover { background: #2563eb; }
      #nlm-repair-banner .nlm-repair-btn:disabled {
        opacity: 0.6; cursor: not-allowed;
      }
      #nlm-repair-banner .nlm-repair-details {
        margin-top: 8px;
        padding-top: 8px;
        border-top: 1px solid #bfdbfe;
        font-size: 12px;
        color: #1e3a8a;
      }
      #nlm-repair-banner .nlm-repair-item {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 3px 0;
        overflow: hidden;
      }
      #nlm-repair-banner .nlm-repair-item-url {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        flex: 1;
      }
      #nlm-repair-banner .nlm-repair-status { flex-shrink: 0; font-size: 11px; }
      #nlm-repair-banner .nlm-repair-success { color: #16a34a; }
      #nlm-repair-banner .nlm-repair-error { color: #dc2626; }
      #nlm-repair-banner .nlm-repair-spinner {
        display: inline-block;
        width: 12px; height: 12px;
        border: 2px solid #fff;
        border-top-color: transparent;
        border-radius: 50%;
        animation: nlm-spin 0.6s linear infinite;
      }
      #nlm-repair-banner .nlm-repair-footer {
        margin-top: 10px;
        padding-top: 8px;
        border-top: 1px solid #bfdbfe;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      #nlm-repair-banner .nlm-repair-footer label {
        display: flex; align-items: center; gap: 6px;
        font-size: 12px; color: #1e3a8a; cursor: pointer; flex: 1;
      }
      #nlm-repair-banner .nlm-repair-footer input[type="checkbox"] {
        accent-color: #3b82f6; width: 14px; height: 14px;
      }
      #nlm-repair-banner .nlm-repair-done-btn {
        padding: 6px 16px; background: #16a34a; color: white;
        border: none; border-radius: 6px; font-size: 12px;
        font-weight: 500; cursor: pointer;
      }
      #nlm-repair-banner .nlm-repair-done-btn:hover { background: #15803d; }
      #nlm-repair-banner .nlm-dismiss {
        background: none; border: none; color: #3b82f6;
        cursor: pointer; font-size: 16px; padding: 0 2px;
        line-height: 1; flex-shrink: 0;
      }
    </style>
    <div class="nlm-repair-header">
      <svg class="nlm-repair-icon" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
      </svg>
      <span class="nlm-repair-text">
        ${x("repair.text",{n:`<strong>${t.length}</strong>`})}
      </span>
      <button class="nlm-repair-btn" id="nlm-repair-btn">
        ${x("repair.btn")}
      </button>
      <button class="nlm-dismiss" id="nlm-repair-dismiss" title="${x("close")}">×</button>
    </div>
    <div class="nlm-repair-details" id="nlm-repair-details" style="display:none">
      ${t.map(m=>`
        <div class="nlm-repair-item" data-url="${m}">
          <span class="nlm-repair-item-url" title="${m}">${m}</span>
          <span class="nlm-repair-status" data-status="pending">${x("repair.pending")}</span>
        </div>
      `).join("")}
    </div>
  `;const r=document.getElementById("nlm-rescue-banner");r&&r.nextSibling?e.insertBefore(n,r.nextSibling):r?e.appendChild(n):e.insertBefore(n,e.firstChild),(o=document.getElementById("nlm-repair-btn"))==null||o.addEventListener("click",()=>{const m=document.getElementById("nlm-repair-btn");m.disabled=!0,m.innerHTML=`<span class="nlm-repair-spinner"></span> ${x("repair.running")}`;const c=document.getElementById("nlm-repair-details");c&&(c.style.display="block");const a=chrome.runtime.connect({name:"repair-wechat"});a.postMessage({urls:t}),a.onMessage.addListener(u=>{if(u.phase==="item-start"){const i=document.querySelector(`#nlm-repair-details .nlm-repair-item[data-url="${CSS.escape(u.url)}"]`),l=i==null?void 0:i.querySelector(".nlm-repair-status");if(l){l.className="nlm-repair-status",l.textContent="";const f=document.createElement("span");f.className="nlm-repair-spinner",l.appendChild(f)}}else if(u.phase==="item-done"){const i=u.result,l=document.querySelector(`#nlm-repair-details .nlm-repair-item[data-url="${CSS.escape(i.url)}"]`),f=l==null?void 0:l.querySelector(".nlm-repair-status");f&&(i.status==="success"?(f.className="nlm-repair-status nlm-repair-success",f.textContent=`✓ ${i.title||x("success")}`):(f.className="nlm-repair-status nlm-repair-error",f.textContent=`✗ ${i.error||x("failed")}`))}else u.phase==="done"?(ae(u.results||[],t),a.disconnect()):u.phase==="error"&&(ae([],t),a.disconnect())})}),(s=document.getElementById("nlm-repair-dismiss"))==null||s.addEventListener("click",()=>{n.remove()})}function ae(t,e){var m;const n=document.getElementById("nlm-repair-btn"),r=t.filter(c=>c.status==="success").length,o=t.filter(c=>c.status==="error").length;n&&(n.style.display="none");const s=document.querySelector("#nlm-repair-banner .nlm-repair-text");s&&(s.innerHTML=`${x("repair.done",{s:r})}${o>0?x("repair.doneFail",{f:o}):""}`);for(const c of t){const a=document.querySelector(`#nlm-repair-details .nlm-repair-item[data-url="${CSS.escape(c.url)}"]`);if(!a)continue;const u=a.querySelector(".nlm-repair-status");u&&(c.status==="success"?(u.className="nlm-repair-status nlm-repair-success",u.textContent=`✓ ${c.title||x("success")}`):(u.className="nlm-repair-status nlm-repair-error",u.textContent=`✗ ${c.error||x("failed")}`))}if(r>0){const c=document.getElementById("nlm-repair-banner");if(c&&!document.getElementById("nlm-repair-footer")){const a=document.createElement("div");a.id="nlm-repair-footer",a.className="nlm-repair-footer",a.innerHTML=`
        <label>
          <input type="checkbox" id="nlm-repair-remove-old" checked />
          ${x("repair.removeOld")}
        </label>
        <button class="nlm-repair-done-btn" id="nlm-repair-done-btn">${x("done")}</button>
      `,c.appendChild(a),(m=document.getElementById("nlm-repair-done-btn"))==null||m.addEventListener("click",async()=>{const u=document.getElementById("nlm-repair-remove-old");u!=null&&u.checked&&await $e(e),c.remove()})}}}async function $e(t){var e;for(const n of t){const r=document.querySelectorAll(".source-title");for(const o of r){if(((e=o.textContent)==null?void 0:e.trim())!==n)continue;const s=o.closest(".single-source-container");if(!s)continue;const m=s.querySelector(".source-item-more-button")||s.querySelector("button");if(!m)continue;m.click(),await p(500);const c=document.querySelector(".more-menu-delete-source-button")||Array.from(document.querySelectorAll('[role="menuitem"], .mat-mdc-menu-item')).find(a=>{var i;const u=((i=a.textContent)==null?void 0:i.trim())||"";return u.includes("移除来源")||u.includes("Remove source")||u.includes("Delete source")});if(c){c.click(),await p(800);const a=document.querySelector("mat-dialog-container .submit-button")||Array.from(document.querySelectorAll("button")).find(u=>{var l;const i=((l=u.textContent)==null?void 0:l.trim())||"";return i==="Delete"||i==="删除"});a&&(a.click(),await p(1e3))}break}}}const Me=[/^https?:\/\/mp\.weixin\.qq\.com\//,/^https?:\/\/(www\.)?(x\.com|twitter\.com)\//];function le(){const t=[];return document.querySelectorAll(".source-title").forEach(n=>{var o;const r=(o=n.textContent)==null?void 0:o.trim();if(r&&Me.some(s=>s.test(r))){const s=n.closest(".single-source-container");s&&!s.classList.contains("single-source-error-container")&&t.push(r)}}),[...new Set(t)]}function ce(){var n,r,o,s;const t=[],e=document.querySelectorAll(".single-source-error-container");for(const m of e){const c=m.querySelector(".source-title"),a=(n=c==null?void 0:c.textContent)==null?void 0:n.trim();a&&/^https?:\/\//.test(a)&&t.push(a)}if(t.length===0){const m=document.querySelectorAll(".source-title-column");for(const c of m){const a=c.closest(".single-source-container");if(!a||!(((o=(r=a.querySelector("mat-icon"))==null?void 0:r.textContent)==null?void 0:o.trim())==="info"))continue;const i=c.querySelector(".source-title"),l=(s=i==null?void 0:i.textContent)==null?void 0:s.trim();l&&/^https?:\/\//.test(l)&&t.push(l)}}return[...new Set(t)]}async function ue(t,e=5e3){const n=Date.now();for(;Date.now()-n<e;){const r=t.split(",").map(o=>o.trim());for(const o of r)try{const s=document.querySelector(o);if(s)return s}catch{}await p(100)}return null}function _e(){var c,a,u;const t="https://notebooklm.google.com",e=window.location.href;let n=null;const r=e.match(/\/notebook\/([a-zA-Z0-9_-]+)/);if(r){const i=r[1],l=document.querySelector('.notebook-title, [class*="notebook-title"], [class*="project-title"], h1'),f=((c=l==null?void 0:l.textContent)==null?void 0:c.trim())||document.title.replace(/ - NotebookLM$/,"").trim()||"Untitled";n={id:i,title:f,url:`${t}/notebook/${i}`}}const o=[],s=document.querySelectorAll('a[href*="/notebook/"]'),m=new Set;for(const i of s){const l=i.href.match(/\/notebook\/([a-zA-Z0-9_-]+)/);if(!l||m.has(l[1]))continue;m.add(l[1]);const w=(i.closest('[class*="card"], [class*="project"], [class*="notebook"]')||i).querySelector('[class*="title"], [class*="name"], h2, h3, .mat-headline, .mat-title'),C=((a=w==null?void 0:w.textContent)==null?void 0:a.trim())||((u=i.textContent)==null?void 0:u.trim())||"Untitled";o.push({id:l[1],title:C,url:`${t}/notebook/${l[1]}`})}return{current:n,list:o}}function Le(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}var U={exports:{}},Pe=U.exports,me;function Re(){return me||(me=1,(function(t,e){(function(n,r){r(t)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:Pe,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",o=s=>{const m={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(m).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class c extends WeakMap{constructor(g,A=void 0){super(A),this.createItem=g}get(g){return this.has(g)||this.set(g,this.createItem(g)),super.get(g)}}const a=d=>d&&typeof d=="object"&&typeof d.then=="function",u=(d,g)=>(...A)=>{s.runtime.lastError?d.reject(new Error(s.runtime.lastError.message)):g.singleCallbackArg||A.length<=1&&g.singleCallbackArg!==!1?d.resolve(A[0]):d.resolve(A)},i=d=>d==1?"argument":"arguments",l=(d,g)=>function(h,...S){if(S.length<g.minArgs)throw new Error(`Expected at least ${g.minArgs} ${i(g.minArgs)} for ${d}(), got ${S.length}`);if(S.length>g.maxArgs)throw new Error(`Expected at most ${g.maxArgs} ${i(g.maxArgs)} for ${d}(), got ${S.length}`);return new Promise((k,E)=>{if(g.fallbackToNoCallback)try{h[d](...S,u({resolve:k,reject:E},g))}catch(b){console.warn(`${d} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,b),h[d](...S),g.fallbackToNoCallback=!1,g.noCallback=!0,k()}else g.noCallback?(h[d](...S),k()):h[d](...S,u({resolve:k,reject:E},g))})},f=(d,g,A)=>new Proxy(g,{apply(h,S,k){return A.call(S,d,...k)}});let w=Function.call.bind(Object.prototype.hasOwnProperty);const C=(d,g={},A={})=>{let h=Object.create(null),S={has(E,b){return b in d||b in h},get(E,b,v){if(b in h)return h[b];if(!(b in d))return;let y=d[b];if(typeof y=="function")if(typeof g[b]=="function")y=f(d,d[b],g[b]);else if(w(A,b)){let P=l(b,A[b]);y=f(d,d[b],P)}else y=y.bind(d);else if(typeof y=="object"&&y!==null&&(w(g,b)||w(A,b)))y=C(y,g[b],A[b]);else if(w(A,"*"))y=C(y,g[b],A["*"]);else return Object.defineProperty(h,b,{configurable:!0,enumerable:!0,get(){return d[b]},set(P){d[b]=P}}),y;return h[b]=y,y},set(E,b,v,y){return b in h?h[b]=v:d[b]=v,!0},defineProperty(E,b,v){return Reflect.defineProperty(h,b,v)},deleteProperty(E,b){return Reflect.deleteProperty(h,b)}},k=Object.create(d);return new Proxy(k,S)},L=d=>({addListener(g,A,...h){g.addListener(d.get(A),...h)},hasListener(g,A){return g.hasListener(d.get(A))},removeListener(g,A){g.removeListener(d.get(A))}}),ze=new c(d=>typeof d!="function"?d:function(A){const h=C(A,{},{getContent:{minArgs:0,maxArgs:0}});d(h)}),de=new c(d=>typeof d!="function"?d:function(A,h,S){let k=!1,E,b=new Promise(D=>{E=function(q){k=!0,D(q)}}),v;try{v=d(A,h,E)}catch(D){v=Promise.reject(D)}const y=v!==!0&&a(v);if(v!==!0&&!y&&!k)return!1;const P=D=>{D.then(q=>{S(q)},q=>{let te;q&&(q instanceof Error||typeof q.message=="string")?te=q.message:te="An unexpected error occurred",S({__mozWebExtensionPolyfillReject__:!0,message:te})}).catch(q=>{console.error("Failed to send onMessage rejected reply",q)})};return P(y?v:b),!0}),We=({reject:d,resolve:g},A)=>{s.runtime.lastError?s.runtime.lastError.message===r?g():d(new Error(s.runtime.lastError.message)):A&&A.__mozWebExtensionPolyfillReject__?d(new Error(A.message)):g(A)},ge=(d,g,A,...h)=>{if(h.length<g.minArgs)throw new Error(`Expected at least ${g.minArgs} ${i(g.minArgs)} for ${d}(), got ${h.length}`);if(h.length>g.maxArgs)throw new Error(`Expected at most ${g.maxArgs} ${i(g.maxArgs)} for ${d}(), got ${h.length}`);return new Promise((S,k)=>{const E=We.bind(null,{resolve:S,reject:k});h.push(E),A.sendMessage(...h)})},He={devtools:{network:{onRequestFinished:L(ze)}},runtime:{onMessage:L(de),onMessageExternal:L(de),sendMessage:ge.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:ge.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},ee={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return m.privacy={network:{"*":ee},services:{"*":ee},websites:{"*":ee}},C(s,He,m)};n.exports=o(chrome)}})})(U)),U.exports}var Ne=Re();const j=Le(Ne);function z(t,...e){}const De={debug:(...t)=>z(console.debug,...t),log:(...t)=>z(console.log,...t),warn:(...t)=>z(console.warn,...t),error:(...t)=>z(console.error,...t)},H=class H extends Event{constructor(e,n){super(H.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=n}};M(H,"EVENT_NAME",X("wxt:locationchange"));let J=H;function X(t){var e;return`${(e=j==null?void 0:j.runtime)==null?void 0:e.id}:notebooklm:${t}`}function Fe(t){let e,n;return{run(){e==null&&(n=new URL(location.href),e=t.setInterval(()=>{let r=new URL(location.href);r.href!==n.href&&(window.dispatchEvent(new J(r,n)),n=r)},1e3))}}}const N=class N{constructor(e,n){M(this,"isTopFrame",window.self===window.top);M(this,"abortController");M(this,"locationWatcher",Fe(this));M(this,"receivedMessageIds",new Set);this.contentScriptName=e,this.options=n,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return j.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,n){const r=setInterval(()=>{this.isValid&&e()},n);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(e,n){const r=setTimeout(()=>{this.isValid&&e()},n);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(e){const n=requestAnimationFrame((...r)=>{this.isValid&&e(...r)});return this.onInvalidated(()=>cancelAnimationFrame(n)),n}requestIdleCallback(e,n){const r=requestIdleCallback((...o)=>{this.signal.aborted||e(...o)},n);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(e,n,r,o){var s;n==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(s=e.addEventListener)==null||s.call(e,n.startsWith("wxt:")?X(n):n,r,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),De.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:N.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){var s,m,c;const n=((s=e.data)==null?void 0:s.type)===N.SCRIPT_STARTED_MESSAGE_TYPE,r=((m=e.data)==null?void 0:m.contentScriptName)===this.contentScriptName,o=!this.receivedMessageIds.has((c=e.data)==null?void 0:c.messageId);return n&&r&&o}listenForNewerScripts(e){let n=!0;const r=o=>{if(this.verifyScriptStartedEvent(o)){this.receivedMessageIds.add(o.data.messageId);const s=n;if(n=!1,s&&(e!=null&&e.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}};M(N,"SCRIPT_STARTED_MESSAGE_TYPE",X("wxt:content-script-started"));let Q=N;const Oe=Symbol("null");let Ke=0;class Ue extends Map{constructor(){super(),this._objectHashes=new WeakMap,this._symbolHashes=new Map,this._publicKeys=new Map;const[e]=arguments;if(e!=null){if(typeof e[Symbol.iterator]!="function")throw new TypeError(typeof e+" is not iterable (cannot read property Symbol(Symbol.iterator))");for(const[n,r]of e)this.set(n,r)}}_getPublicKeys(e,n=!1){if(!Array.isArray(e))throw new TypeError("The keys parameter must be an array");const r=this._getPrivateKey(e,n);let o;return r&&this._publicKeys.has(r)?o=this._publicKeys.get(r):n&&(o=[...e],this._publicKeys.set(r,o)),{privateKey:r,publicKey:o}}_getPrivateKey(e,n=!1){const r=[];for(let o of e){o===null&&(o=Oe);const s=typeof o=="object"||typeof o=="function"?"_objectHashes":typeof o=="symbol"?"_symbolHashes":!1;if(!s)r.push(o);else if(this[s].has(o))r.push(this[s].get(o));else if(n){const m=`@@mkm-ref-${Ke++}@@`;this[s].set(o,m),r.push(m)}else return!1}return JSON.stringify(r)}set(e,n){const{publicKey:r}=this._getPublicKeys(e,!0);return super.set(r,n)}get(e){const{publicKey:n}=this._getPublicKeys(e);return super.get(n)}has(e){const{publicKey:n}=this._getPublicKeys(e);return super.has(n)}delete(e){const{publicKey:n,privateKey:r}=this._getPublicKeys(e);return!!(n&&super.delete(n)&&this._publicKeys.delete(r))}clear(){super.clear(),this._symbolHashes.clear(),this._publicKeys.clear()}get[Symbol.toStringTag](){return"ManyKeysMap"}get size(){return super.size}}new Ue;function Ye(){}function W(t,...e){}const je={debug:(...t)=>W(console.debug,...t),log:(...t)=>W(console.log,...t),warn:(...t)=>W(console.warn,...t),error:(...t)=>W(console.error,...t)};return(async()=>{try{const{main:t,...e}=pe,n=new Q("notebooklm",e);return await t(n)}catch(t){throw je.error('The content script "notebooklm" crashed on startup!',t),t}})()})();
notebooklm;
